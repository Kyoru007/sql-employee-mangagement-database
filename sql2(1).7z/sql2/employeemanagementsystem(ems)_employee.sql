-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: employeemanagementsystem(ems)
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee` (
  `Employee_Id` int NOT NULL,
  `First_Name` varchar(60) DEFAULT NULL,
  `Last_name` varchar(55) DEFAULT NULL,
  `Bday` datetime DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `phone` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `hire_date` datetime DEFAULT NULL,
  `job_title` varchar(45) DEFAULT NULL,
  `dept_id` int DEFAULT NULL,
  PRIMARY KEY (`Employee_Id`),
  UNIQUE KEY `Employee Id_UNIQUE` (`Employee_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee`
--

LOCK TABLES `employee` WRITE;
/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
INSERT INTO `employee` VALUES (1,'Mainur','Akash','2001-08-03 00:00:00','Mohammadpur,Iqbal Road,Dhaka','01784387xxx','mainurakash@gmail.com','2023-02-02 00:00:00','Weather analyst',11),(2,'Fardin','Siam','2002-09-20 00:00:00','Motijheel ,Dhaka','018748028XX','fsiam@gmail.com','2023-02-02 00:00:00','assistant relief manager',22),(3,'Muktadirul','Sowad','2002-01-21 00:00:00','Kallyanpur,Dhaka','0179537XXXX','sowad@gmail.com','2023-02-02 00:00:00','offensive security engineer',33),(4,'Sadia','Tasnim','2002-04-17 00:00:00','Begum Rokeya hall,DU,Dhaka','01777839XXX','tsadia@gmail.com','2023-02-02 00:00:00','meteorologist',44),(5,'Anan','Afrida','2002-01-11 00:00:00','Dhanmondi , Dhaka','0178492XX','aanan@gmail.com','2023-02-02 00:00:00','Senior Software Engineer',55),(6,'Sajid','Khan','2002-11-28 00:00:00','Farmgate, Dhaka','0174389584','0khansahil@gmail.com','2023-02-02 00:00:00','weather analyst',11),(7,'ishraq','arig','2002-08-03 00:00:00','town hall, dhaka','0047495745','afadsfds@gmail.com','2023-02-02 00:00:00','weather analyst',11);
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-01 23:41:35
